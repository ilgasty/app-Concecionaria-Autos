import React, { useEffect, useState } from 'react'
import { GetMercadoLibre } from '../helper/GetMercadoLibre'
import { GridAutoItem } from './GridAutoItem';


export const GridAuto = () => {
    
    const [state, setstate] = useState({
        autos:[],
        
    });
    
    useEffect(() => {
        //console.log('prueba 1')
        GetMercadoLibre().then(imgs=>{
            setstate({
                autos:imgs,
              });    
           });
    }, [])
    

//console.log(autos)
    return (
        <>
             <div className="card-grid">
                        
                        {state.autos.map((img)=> (
                        <GridAutoItem key={img.id} {...img}/>
                        ))}
                             
              
            </div>
        </>
    )
}
